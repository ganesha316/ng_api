<?php
	$this->load->view('user/common/login_header');
	$this->load->view($view);
	$this->load->view('user/common/login_footer');
?>