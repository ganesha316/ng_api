<?php
	$this->load->view('admin/login/login_header');
	$this->load->view($view);
	$this->load->view('admin/login/login_footer');
?>