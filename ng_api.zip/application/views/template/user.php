<?php
	$this->load->view('user/common/header');
	$this->load->view($view);
	$this->load->view('user/common/footer');
?>