<!-- /.content-wrapper -->
<footer class="main-footer">
   <strong>Copyright &copy; <?php echo date('Y'); ?> <a href="<?php echo base_url() ?>"><?php echo rtrim(str_replace(['https://','http://'],'',base_url()),'/') ?></a>.</strong> All rights reserved.
</footer>
</div>
<!-- ./wrapper -->

<input id="secRef" type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>" />

<!-- jQuery 3 -->
<script src="<?php echo $this->config->item('admin_asset'); ?>bower_components/jquery/dist/jquery.min.js"></script>
<!-- Bootstrap 3.3.7 -->
<script src="<?php echo $this->config->item('admin_asset'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
<!-- FastClick -->
<script src="<?php echo $this->config->item('admin_asset'); ?>bower_components/fastclick/lib/fastclick.js"></script>
<!-- AdminLTE App -->
<script src="<?php echo $this->config->item('admin_asset'); ?>dist/js/adminlte.min.js"></script>
<!-- sweetalert -->
<script src="<?php echo $this->config->item('admin_asset'); ?>bower_components/sweetalert/dist/sweetalert2.min.js"></script>
<!-- common js -->
<script src="<?php echo $this->config->item('admin_asset'); ?>dist/js/common.js"></script>

<script src="//cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>

<?php
if(isset($js))
{
    if(is_array($js))
    {
        foreach ($js as $js_file) {
            echo "<script src='".$this->config->item('admin_asset').$js_file."?v=".time()."'></script>\n";
        }
    }

    if(is_string($js))
    {
        echo "<script src='".$this->config->item('admin_asset').$js."?v=".time()."'></script>";
    }
}
?>
<?php if ($swal = $this->session->flashdata('swal')) {
    $swal = is_array($swal) ? json_encode($swal) : $swal;
?>
<script type="text/javascript">
    Swal.fire(<?= $swal; ?>);
</script>
<?php } ?>


</body>
</html>