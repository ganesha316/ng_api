<!-- Left side column. contains the logo and sidebar -->
<aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
        <!-- Sidebar user panel -->
        <!-- <div class="user-panel">
            <div class="pull-left image">
                <div class="profile-icon">R</div>
            </div>
            <div class="pull-left info">
                <p>Alexander Pierce</p>
            </div>
        </div> -->
        
        <!-- sidebar menu: : style can be found in sidebar.less -->
        <ul class="sidebar-menu" data-widget="tree">

            <li class="<?= set_menu(2,'category') ?>"><a href="<?= admin_url('category') ?>"><i class="fa fa-th"></i> <span>Categories </span> </a></li>

            <li class="<?= set_menu(2,'projects') ?>"><a href="<?= admin_url('projects') ?>"><i class="fa fa-tasks"></i> <span>Projects </span> </a></li>

            <li class="<?= set_menu(2,'home_gallery') ?>"><a href="<?= admin_url('home_gallery') ?>"><i class="fa fa-images"></i><span> Home Gallery </span> </a></li>

            <li class="<?= set_menu(2,'home_cms') ?>"><a href="<?= admin_url('home_cms') ?>"><i class="fa fa-file-alt"></i><span> Home CMS </span> </a></li>

            <li class="<?= set_menu(2,'change_password') ?>"><a href="<?= admin_url('change_password') ?>"><i class="fa fa-key"></i><span> Change Password </span> </a></li>
        </ul>
    </section>
    <!-- /.sidebar -->
</aside>

<?php if ($this->session->userdata('email_verified') == 'no'){ ?>
<div class="message-wrapper" style="min-height: 0px !important;">
    <div class="alert alert-warning mb-0">
        <h4><i class="icon fa fa-warning"></i> Alert! Your Email id is not verified yet. Please chek your email for verification link or <a href="<?= admin_url('login/email_verifiction') ?>">click here</a> to regerate </h4>
    </div>
</div>
<?php } ?>