<section class="content-header">
	<h1>
		<?= $form_title ?>
		<small><?= isset($preview) ? $preview : '' ?></small>
	</h1>

	<?php if (isset($breadcrumb)){ ?>			
	<ol class="breadcrumb">
		<?php foreach ($breadcrumb as $key => $value){ ?>
		<li><a href="<?= $value['href'] ?>"> <?= $value['name'] ?> </a></li>
		<?php } ?>
	</ol>
	<?php } ?>
</section>