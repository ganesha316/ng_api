<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<?php $this->load->view('admin/common/module_header'); ?>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<!-- left column -->
			<div class="col-md-12">
				<div class="box box-primary">
					<!-- form start -->
					<form role="form" id="change_password_form" enctype="multipart/form-data">
						<div class="box-body">
							<?= csrf_input(); ?>
							
							<div class="form-group old_pass_field">
								<label for="old_password_input">Old Password</label>
								<input type="password" class="form-control" name="old_password" id="old_password_input" placeholder="Enter Old Password">
								<span class="form_error" id="err_old_password"></span>
							</div>

							<div class="form-group new_pass_field" style="display: none">
								<label for="new_password_input">New Password</label>
								<input type="password" class="form-control" name="new_password" id="new_password_input" placeholder="Enter New Password">
								<span class="form_error" id="err_new_password"></span>
							</div>

							<div class="form-group new_pass_field" style="display: none">
								<label for="c_new_password_input">Confirm Password</label>
								<input type="password" class="form-control" name="c_new_password" id="c_new_password_input" placeholder="Enter Confirm Password">
								<span class="form_error" id="err_c_new_password"></span>
							</div>

							<div class="form-group new_pass_field" style="display: none">
								<label for="otp_input">OTP</label>
								<input type="text" class="form-control" name="otp" id="otp_input" placeholder="Enter Confirm Password">
								<span class="form_error" id="err_otp"></span>
							</div>
						</div>
						<!-- /.box-body -->

						<div class="box-footer verify_password_div">
							<button type="submit" class="btn btn-primary" id="verify_password">Submit</button>
						</div>

						<div class="box-footer new_pass_field" style="display: none">
							<button type="submit" class="btn btn-primary" id="change_password_btn">Change Password</button>
						</div>
					</form>
				</div>
				<!-- /.box -->
			</div>
			<!--/.col (left) -->
		</div>
		<!-- /.row -->
	</section>
	<!-- /.content -->
</div>
<!-- /.content-wrapper -->