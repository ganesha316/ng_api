<style type="text/css">
    .otp-back{
        padding-bottom: 26px;
        font-size: 15px;
        cursor: pointer;
    }
</style>
<div class="register-box">
    <div class="register-logo">
        <a href="<?php echo $this->config->item('admin_asset'); ?>index2.html"><b><?= $this->config->item('project_name'); ?></b></a>
    </div>

    <div class="register-box-body" id="register_form_div">
        <p class="login-box-msg">Register a new membership</p>

        <form action="" id="register_form" method="post">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>" />
            <div class="form-group has-feedback">
                <label>Mobile Number</label>
                <input type="text" class="form-control" placeholder="10 digit Mobile Number" name="mobile">
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
                <span class="form_error" id="err_mobile"></span>
            </div>
            <div class="form-group has-feedback">
                <label>Email</label>
                <input type="email" class="form-control" placeholder="Email" name="email">
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                <span class="form_error" id="err_email"></span>
            </div>
            <div class="form-group has-feedback">
                <label>Password</label>
                <input type="password" class="form-control" placeholder="Password" name="password">
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                <span class="form_error" id="err_password"></span>
            </div>
            <div class="form-group has-feedback">
                <label>Confirm Password</label>
                <input type="password" class="form-control" placeholder="Retype password" name="c_password">
                <span class="glyphicon glyphicon-log-in form-control-feedback"></span>
                <span class="form_error" id="err_c_password"></span>
            </div>
            <div class="row">
                <div class="col-xs-8">
                    <div class="checkbox icheck">
                        <label>
                            <input type="checkbox" name="accept_terms" value="on"> I agree to the <a href="#">terms</a>
                        </label>
                    </div>
                    <span class="form_error" id="err_accept_terms"></span>
                </div>
                <!-- /.col -->
                <div class="col-xs-4">
                    <button type="submit" class="btn btn-primary btn-block btn-flat" id="register_submit">Register</button>
                </div>
                <!-- /.col -->
            </div>
        </form>

        <a href="<?= admin_url('login')  ?>" class="text-center">I already have a membership</a>
    </div>

    <div class="register-box-body" id="otp_form_div" style="display: none">
        <div class="row">
            <div class="col-xs-4 pull-left otp-back">
                <a class="cus_pointer">Back</a>
            </div>
        </div>
        <form id="otp_form" method="post">
            <div class="form-group has-feedback">
                <label>Enter OTP</label>
                <input type="text" class="form-control" placeholder="Enter OTP" name="otp">
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
                <span class="form_error" id="err_otp"></span>
                <p class="help-block" id="resend_otp_div"></p>
            </div>
            <div class="row">
                <!-- /.col -->
                <div class="col-xs-4 pull-right">
                    <button type="submit" class="btn btn-primary btn-block btn-flat" id="otp_submit">Submit</button>
                </div>
                <!-- /.col -->
            </div>
        </form>
    </div>
    <!-- /.form-box -->
</div>
<!-- /.register-box -->


