<div class="login-box">
    <div class="login-logo">
        <a href="#"><b><?= $this->config->item('project_name'); ?></b></a>
    </div>
    <!-- /.login-logo -->
    
    <div class="register-box-body" id="otp_form_div">
        <div class="row">
            <div class="col-xs-4 pull-left otp-back">
                <a href="<?= admin_url('login'); ?>" class="cus_pointer">Back</a>
            </div>
        </div>
        <form id="otp_form" method="post">
            <div class="form-group has-feedback">
                <label>Registered Email</label>
                <input type="text" name="user_id" class="form-control" placeholder="Email">
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                <span class="form_error" id="err_user_id"></span>
            </div>

            <div class="form-group has-feedback" id="otp_input" style="display:none">
                <label>Enter OTP</label>
                <input type="text" class="form-control" placeholder="Enter OTP" name="otp">
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
                <span class="form_error" id="err_otp"></span>
            </div>
            <div class="row">
                <!-- /.col -->
                <div class="col-xs-4 pull-right">
                    <button class="btn btn-primary btn-block btn-flat" id="mobile_submit">Send OTP</button>
                    <button class="btn btn-primary btn-block btn-flat" id="otp_submit" style="display: none;">Submit</button>
                </div>
                <!-- /.col -->
            </div>
        </form>
    </div>

    <div class="register-box-body" id="password_reset_div" style="display: none">
        <div class="row">
            <div class="col-xs-4 pull-left otp-back">
                <a href="<?= admin_url('login'); ?>" class="cus_pointer">Back</a>
            </div>
        </div>
        <form id="password_reset_form" method="post">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>" />
            <div class="form-group has-feedback">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Enter Password">
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                <span class="form_error" id="err_password"></span>
            </div>

            <div class="form-group has-feedback">
                <label>Confirm password</label>
                <input type="password" class="form-control" placeholder="Confirm password" name="c_password">
                <span class="glyphicon glyphicon-user form-control-feedback"></span>
                <span class="form_error" id="err_c_password"></span>
            </div>
            <div class="row">
                <!-- /.col -->
                <div class="col-xs-4 pull-right">
                    <button class="btn btn-primary btn-block btn-flat" id="password_reset_submit">Submit</button>
                </div>
                <!-- /.col -->
            </div>
        </form>
    </div>
</div>
<!-- /.login-box -->