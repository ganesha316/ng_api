<div class="login-box">
    <div class="login-logo">
        <a href="#"><b><?= $this->config->item('project_name'); ?></b></a>
    </div>
    <!-- /.login-logo -->
    <div class="login-box-body" id="login_form_div">
        <p class="login-box-msg">Sign in to start your session</p>

        <form action="#" method="post" id="login_form">
            <input type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>" />
            <div class="form-group has-feedback">
                <label>Registered Email</label>
                <input type="text" name="user_id" class="form-control" placeholder="Email">
                <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
                <span class="form_error" id="err_user_id"></span>
            </div>
            <div class="form-group has-feedback">
                <label>Password</label>
                <input type="password" name="password" class="form-control" placeholder="Password">
                <span class="glyphicon glyphicon-lock form-control-feedback"></span>
                <span class="form_error" id="err_password"></span>
            </div>
            <div class="row">
                <div class="col-xs-4 pull-right">
                    <button type="submit" class="btn btn-primary btn-block btn-flat" id="login_submit">Sign In</button>
                </div>
                <!-- /.col -->
            </div>
        </form>

        <a href="<?= admin_url('forgot_password'); ?>">I forgot my password</a><br>
    </div>
    <!-- /.login-box-body -->
</div>
<!-- /.login-box -->