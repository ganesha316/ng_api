    <input id="secRef" type="hidden" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>" />
    <!-- jQuery 3 -->
    <script src="<?php echo $this->config->item('admin_asset'); ?>bower_components/jquery/dist/jquery.min.js"></script>
    <!-- Bootstrap 3.3.7 -->
    <script src="<?php echo $this->config->item('admin_asset'); ?>bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
    <!-- iCheck -->
    <script src="<?php echo $this->config->item('admin_asset'); ?>plugins/iCheck/icheck.min.js"></script>
    <!-- sweetalert -->
    <script src="<?php echo $this->config->item('admin_asset'); ?>bower_components/sweetalert/dist/sweetalert2.min.js"></script>
    <!-- commonjs -->
    <script src="<?php echo $this->config->item('admin_asset'); ?>dist/js/common.js"></script>

    <?php if ($page_name == 'login') { ?>
    <script src="https://apis.google.com/js/platform.js?onload=googleRenderButton" async defer></script>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v3.3&appId=1158223451016917&autoLogAppEvents=1"></script>
    <script src="<?php echo $this->config->item('admin_asset'); ?>dist/js/pages/login.js"></script>
    <?php } ?>
    
    <?php if ($page_name == 'register') { ?>
    <script src="<?php echo $this->config->item('admin_asset'); ?>dist/js/pages/register.js"></script>
    <?php } ?>

    <?php if ($page_name == 'forgot_password') { ?>
    <script src="<?php echo $this->config->item('admin_asset'); ?>dist/js/pages/forgot_password.js"></script>
    <?php } ?>
</body>
</html>