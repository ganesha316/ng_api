<!-- Content Wrapper. Contains page content -->
<div class="content-wrapper">
	<!-- Content Header (Page header) -->
	<?php $this->load->view('admin/common/module_header'); ?>

	<!-- Main content -->
	<section class="content">
		<div class="row">
			<!-- left column -->
			<div class="col-md-12">
				<div class="box box-primary">
					<!-- form start -->
					<form role="form" id="add_category_form" enctype="multipart/form-data">
						<div class="box-body">
							<?= csrf_input(); ?>
							<input type="hidden" name="id" value="<?= set_value('id',$category['id']) ?>">
							<input type="hidden" name="form_type" value="<?= $form_type ?>">

							<div class="form-group">
								<label for="name_input">Name</label>
								<input type="text" class="form-control createSlug" name="name" id="name_input" placeholder="Enter Name" value="<?= set_value('name',$category['name']) ?>">
								<span class="form_error" id="err_name"></span>
							</div>

							<div class="form-group">
								<label for="slug_input">Slug</label>
								<input type="text" class="form-control slugValue" name="slug" id="slug_input" placeholder="Enter Slug" value="<?= set_value('slug',$category['slug']) ?>">
								<span class="form_error" id="err_slug"></span>
							</div>

							<div class="form-group">
								<label for="bg_color_input">Background Color</label>
								<input type="text" class="form-control jscolor" name="bg_color" id="bg_color_input" placeholder="Enter Background Color" value="<?= set_value('bg_color',$category['bg_color']) ?>">
								<span class="form_error" id="err_bg_color"></span>
							</div>

							<div class="form-group">
                                <label for="banner_name_input">Inner Banner Name</label>
                                <input type="text" class="form-control" name="banner_name" id="banner_name_input" placeholder="Enter Banner Name" value="<?= set_value('banner_name',$category['banner_name']) ?>">
                                <span class="form_error" id="err_banner_name"></span>
                            </div>

                            <div class="form-group">
                                <label for="banner_image_file_input">Inner Banner Image</label>
                                <?php if(!empty($category['banner_image'])){ ?>
                                <div class="mb-10"><img width="200" src="<?= base_url('uploads/category/banner/'.$category['banner_image']) ?>"></div>
                                <?php } ?>
                                <input type="file" name="banner_image" id="banner_image_file_input">
                                <p class="help-block">Only JPG, PNG allowed (Max width <?= $this->banner_image_width ?>px)</p>
                                <span class="form_error" id="err_banner_image"></span>
                            </div>

                            <div class="form-group">
                                <label for="content_text">Inner Content</label>
                                <textarea name="content" id="content_text" class="form-control" rows="3" placeholder="Enter Content"><?= set_value('content',$category['content']) ?></textarea>
                                <span class="form_error" id="err_content"></span>
                            </div>

							<div class="form-group">
								<label for="sort_order_input">Sort Order</label>
								<input type="text" class="form-control" name="sort_order" id="sort_order_input" placeholder="Enter Sort Order" value="<?= set_value('sort_order',$category['sort_order']) ?>">
								<span class="form_error" id="err_sort_order"></span>
							</div>

							<div class="form-group">
								<label for="status_select">Status</label>
								<select class="form-control" name="status" id="status_select">
									<option value="active" <?= set_select('status','active',($category['status'] == 'active')) ?>>Active</option>
									<option value="inactive" <?= set_select('status','inactive',($category['status'] == 'inactive')) ?>>In Active</option>
								</select>
								<span class="form_error" id="err_status"></span>
							</div>
						</div>
						<!-- /.box-body -->

						<div class="box-footer">
							<button type="submit" class="btn btn-primary" id="add_category_btn">Submit</button>
						</div>
					</form>
				</div>
				<!-- /.box -->
			</div>
			<!--/.col (left) -->
		</div>
		<!-- /.row -->
	</section>
	<!-- /.content -->
</div>
<!-- /.content-wrapper -->