<?php
	/*$config = array(
		'forgot_password' => [
			[
				'field' => 'user_id',
				'label' => 'Email',
				'rules' => 'trim|required|valid_email|callback_validate_user',
				'errors'=> [
					'validate_user' => 'This Email does not belongs to our system'
				],
			],
		],
		
		'reset_password' => [
			[
				'field' => 'password',
				'label' => 'Password',
				'rules' => 'trim|required|callback_strong_password',
				'errors' => [
					'strong_password' => 'A password must be minimum of 8 characters in length must contain at least one uppercase letter, at least one digit, at least one of the following special characters !@#$%^&*-',
				]
			],
			[
				'field' => 'c_password',
				'label' => 'Confirm password',
				'rules' => 'trim|required|matches[password]',
			],
		],
	);*/