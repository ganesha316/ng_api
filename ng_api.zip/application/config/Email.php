<?php

/*$config = array(
	'protocol' => "smtp",
	'smtp_host' => "ssl://smtp.gmail.com",
	'smtp_port' => "465",
	'smtp_user' => "ganeshpatil0711@gmail.com",
	'smtp_pass' => "jihedxbawkyvwdsg",
	'charset' => "utf-8",
	'mailtype' => "html",
	'newline' => "\r\n",
);*/