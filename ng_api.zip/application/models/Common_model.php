<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Common_model extends MY_Model {
	
}

/* End of file Common_model.php */
/* Location: ./application/models/Common_model.php */