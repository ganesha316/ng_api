<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2020-02-23 12:47:05 --> Query error: Table 'ng_api_db.ss_home_cms' doesn't exist - Invalid query: SELECT *
FROM `ss_home_cms`
 LIMIT 1
ERROR - 2020-02-23 12:48:03 --> 404 Page Not Found: api//index
ERROR - 2020-02-23 12:48:37 --> 404 Page Not Found: api/v1/Category/index
ERROR - 2020-02-23 13:56:43 --> Severity: Notice --> Undefined property: Category::$common /var/www/html/ng_api/application/controllers/api/v1/Category.php 13
ERROR - 2020-02-23 13:56:43 --> Severity: error --> Exception: Call to a member function select_data_array_options() on null /var/www/html/ng_api/application/controllers/api/v1/Category.php 13
ERROR - 2020-02-23 13:58:23 --> Severity: Notice --> Undefined property: Category::$load /var/www/html/ng_api/application/controllers/api/v1/Category.php 9
ERROR - 2020-02-23 13:58:23 --> Severity: error --> Exception: Call to a member function model() on null /var/www/html/ng_api/application/controllers/api/v1/Category.php 9
ERROR - 2020-02-23 13:59:12 --> Query error: Table 'ng_api_db.ss_category' doesn't exist - Invalid query: SELECT `id`, `name`
FROM `ss_category`
ERROR - 2020-02-23 13:59:22 --> Severity: Notice --> Use of undefined constant HTTP_OK - assumed 'HTTP_OK' /var/www/html/ng_api/application/core/MY_Controller.php 70
ERROR - 2020-02-23 14:01:18 --> Severity: Notice --> Use of undefined constant HTTP_OK - assumed 'HTTP_OK' /var/www/html/ng_api/application/core/MY_Controller.php 70
ERROR - 2020-02-23 14:04:18 --> Severity: error --> Exception: syntax error, unexpected 'const' (T_CONST) /var/www/html/ng_api/application/core/MY_Controller.php 27
ERROR - 2020-02-23 14:04:33 --> Severity: error --> Exception: syntax error, unexpected 'const' (T_CONST) /var/www/html/ng_api/application/core/MY_Controller.php 27
